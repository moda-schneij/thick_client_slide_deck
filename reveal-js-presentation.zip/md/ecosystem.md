## Thick client ecosystem & pipeline
<span class="fragment" data-fragment-index="1">
![alt text](images/nodeNPM.png "Node and NPM Logos") <!-- .element: class="inline-with-content" -->
![alt text](images/webpack.png "Webpack Logo") <!-- .element: class="inline-with-content" -->
</span>