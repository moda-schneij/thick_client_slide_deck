![alt text](images/angular_services.png "Angular services") <!-- .element: class="inline-with-content" -->

Services: Do the majority of the work in an application, called by all other classes to handle logic, GET and POST data, etc. <!-- .element: class="fragment" -->

Injectors: Provide services to modules and components, in a hierarchical DI system <!-- .element: class="fragment" -->
