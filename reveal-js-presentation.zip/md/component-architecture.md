## Component architecture
![alt text](images/component_arch.png "Component architecture") <!-- .element: class="inline-with-content angular-overview" -->