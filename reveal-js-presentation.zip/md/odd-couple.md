### Now who's in charge?
<img src="images/odd_couple.jpg">