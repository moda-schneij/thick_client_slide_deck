## State management

![alt text](images/the-state.jpg "The state") <!-- .element: class="inline-with-content angular-overview -->