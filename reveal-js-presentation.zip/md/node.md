## NodeJS
- JS for the filesystem (server, development box, deployment box) <!-- .element: class="fragment" data-fragment-index="1" -->
- Runs all development and build tasks <!-- .element: class="fragment" data-fragment-index="2" -->
- Hosts task runners (e.g., Grunt, Gulp), scripting tools (NPM scripts), module loading and bundling tools (e.g., Webpack, SystemJS, Rollup) <!-- .element: class="fragment" data-fragment-index="3" -->