## Node Package Manager
- NPM scripts define common tasks (serve, build, test, etc.) and can provide environment variables for customization in development and production stages <!-- .element: class="fragment" data-fragment-index="1" -->
- Other tools build on NPM <!-- .element: class="fragment" data-fragment-index="2" -->
  - NG CLI <!-- .element: class="fragment" data-fragment-index="3" -->
  - Yarn <!-- .element: class="fragment" data-fragment-index="4" -->