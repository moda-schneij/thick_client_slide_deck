## Keepin' it Thick (TM)

![alt text](images/thicke_sm.jpg "Thicke") <!-- .element: class="inline-with-content angular-overview -->