## Angular in a nutshell

ES6/TypeScript and a module bundler enable file-system imports and exports of user-defined and NPM-provided modules <!-- .element: class="fragment" data-fragment-index="1" -->

Then Angular takes over... <!-- .element: class="fragment" data-fragment-index="2" -->
