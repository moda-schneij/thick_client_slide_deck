## Node Package Manager
- Both a repository and tool <!-- .element: class="fragment" data-fragment-index="1" -->
- Repository hosts modules (utilities, tools, libraries, and frameworks, like Angular) <!-- .element: class="fragment" data-fragment-index="2" -->
- Tool imports versioned modules -- whatever's needed to build an application <!-- .element: class="fragment" data-fragment-index="3" -->
- Can declare both development and build dependencies (those that will be bundled for delivery to the client) <!-- .element: class="fragment" data-fragment-index="4" -->