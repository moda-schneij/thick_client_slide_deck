## State management

- State in thick-client web applications is updated from all over the UI and in response to network requests, asynchronously <!-- .element: class="fragment" -->
- Need patterns for avoiding unpredictability and chaos <!-- .element: class="fragment" -->