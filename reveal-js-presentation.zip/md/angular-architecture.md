## Angular architecture
![alt text](images/angular_overview.png "Angular Overview") <!-- .element: class="inline-with-content angular-overview" -->