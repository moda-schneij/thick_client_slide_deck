![alt text](images/angular_modules.png "Angular Modules") <!-- .element: class="inline-with-content" -->

NgModules: Define the structure of the Angular application, bootstrap it, and make the compiler aware of all Angular-specific code <!-- .element: class="fragment" data-fragment-index="1" -->