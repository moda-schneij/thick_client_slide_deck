## Best practices

![alt text](images/best-practices.gif "Best practices") <!-- .element: class="inline-with-content angular-overview -->
