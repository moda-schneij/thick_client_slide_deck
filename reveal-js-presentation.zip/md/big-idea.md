## The big idea
<img src="images/pb_choc.jpg"> <!-- .element: class="fragment" data-fragment-index="1" -->