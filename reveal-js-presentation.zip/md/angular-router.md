![alt text](images/angular_router.jpg "Angular router") <!-- .element: class="inline-with-content" -->

Router: Takes in or activates a parameterized URL to activate a hierarchy of components with state set according to URL parameters and route configuration data <!-- .element: class="fragment" data-fragment-index="1" -->