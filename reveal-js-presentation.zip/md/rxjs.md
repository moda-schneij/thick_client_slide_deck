## RxJS ![alt text](images/Rx_Logo_S.png "RxJS Logo") <!-- .element: class="inline-with-content" -->
- Observable streams with functional operators for JS <!-- .element: class="fragment" data-fragment-index="1" -->
- Powerful, flexible, concise way to continuously project asynchronous data (REST, user interaction) to views <!-- .element: class="fragment" data-fragment-index="2" -->
- Powerful way to implement state management for Angular <!-- .element: class="fragment" data-fragment-index="3" -->
- Used by several Angular modules out-of-the-box <!-- .element: class="fragment" data-fragment-index="4" -->