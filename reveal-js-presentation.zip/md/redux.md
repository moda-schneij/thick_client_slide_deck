## Redux

![alt text](images/redux.jpg "Redux") <!-- .element: class="inline-with-content angular-overview -->