## Angular CLI

- Can generate an entire Angular application skeleton as well as any of the building blocks of an application <!-- .element: class="fragment" data-fragment-index="1" -->
- Sets up development environment, including live dev server, Webpack for module loading and bundling, and Karma/Jasmine/Protractor for running unit and E2E tests <!-- .element: class="fragment" data-fragment-index="2" -->